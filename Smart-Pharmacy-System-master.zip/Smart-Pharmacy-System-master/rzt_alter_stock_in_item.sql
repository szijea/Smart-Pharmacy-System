ALTER TABLE stock_in_item MODIFY medicine_id VARCHAR(255) NOT NULL;

