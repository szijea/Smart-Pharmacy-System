package com.pharmacy.tools;

public class ExcelImportTest {
    public static void main(String[] args) {
        System.out.println("ExcelImportTest 已禁用，未引入 Apache POI 依赖。");
        System.out.println("如需本地调试 Excel 解析，请单独添加 poi-ooxml 依赖并实现解析逻辑。");
    }
}
