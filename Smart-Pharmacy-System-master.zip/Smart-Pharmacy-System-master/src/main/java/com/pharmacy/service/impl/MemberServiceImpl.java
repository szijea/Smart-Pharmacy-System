package com.pharmacy.service.impl;

public class MemberServiceImpl {
}
