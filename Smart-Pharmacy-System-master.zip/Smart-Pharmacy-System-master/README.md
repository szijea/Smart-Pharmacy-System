# 智慧药房收银管理系统 (Pharmacy Management System)

基于 Spring Boot + MySQL + Docker 开发的现代化多租户药房SaaS管理系统。支持收银、库存管理、会员管理、多租户运营及数据分析。

## 📋 功能特性

- **多租户架构**: 支持多店铺（bht, wx, rzt）独立数据隔离，统一后台管理。
- **收银台 (POS)**: 快速商品录入、扫码枪支持、挂单/取单、多种支付方式。
- **药品管理**: 药品基础信息维护、过期预警、库存预警、Excel 批量导入/导出。
- **库存管理**: 入库单管理、库存调拨（租户间流转）、库存盘点。
- **会员体系**: 会员等级、积分管理、积分兑换福利、消费记录分析、流失预警。
- **数据报表**: 销售趋势图、药品分类占比、员工业绩考核、AI 智能分析（开发中）。
- **权限控制**: 店长(Boss)与员工权限分离。

## 🛠️ 技术栈

- **后端**: Java 17, Spring Boot 3.2.0, Spring Data JPA
- **数据库**: MySQL 8.0, H2 (Local Dev)
- **部署**: Docker, Docker Compose
- **前端**: HTML5, Tailwind CSS, Vanilla JS (无复杂的构建流程，开箱即用)
- **工具**: Maven, Lombok

## 🚀 快速开始

### 方式一：Docker 一键部署 (推荐)

1. **环境准备**: 确保已安装 Docker 和 Docker Compose。
2. **下载代码**: 克隆本项目到本地。
3. **启动服务**:
   在项目根目录下运行 PowerShell 或终端命令：
   ```bash
   docker-compose up -d --build
   ```
4. **访问系统**:
   - 浏览器打开: `http://localhost:8080`
   - 等待几秒钟，数据库初始化脚本会自动执行。

### 方式二：本地开发运行

1. **环境准备**: JDK 17+, Maven 3.6+, MySQL 8.0。
2. **数据库配置**:
   - 创建数据库 `rzt_db`, `bht`, `wx` (或者依赖应用的自动初始化脚本)。
   - 修改 `src/main/resources/application.yaml` 中的数据库连接信息（如密码）。
3. **编译运行**:
   ```bash
   # Windows
   .\mvnw.cmd clean spring-boot:run
   
   # Linux/Mac
   ./mvnw clean spring-boot:run
   ```

## 📖 使用指南

### 1. 登录系统
- **Boss后台登录**: 
  - 访问 `http://localhost:8080` 或 `http://localhost:8080/boss-login.html`
  - 默认账号: `boss`
  - 默认密码: `123456`
  - *无需选择特定租户，Boss账号拥有跨租户管理权限。*

### 2. 主要功能模块
- **控制台**: 查看今日销售额、订单数、库存预警及近效期药品。
- **收银管理**: 前台收银操作界面。
- **药品管理**: 
  - 支持 `.xlsx` 文件批量导入药品数据。
  - 支持导出当前药品清单。
- **库存管理**:
  - **药品入库**: 批量入库操作。
  - **库存调拨**: 支持不同店铺/仓库间的库存转移。
- **会员管理**:
  - 会员增删改查、批量导入/导出。
  - **福利兑换**: 设置积分兑换商品，前台进行兑换操作。
  - 消费分析图表。

## 📂 项目结构

```
springboot-main-main
├── src/main/java          # 后端源代码
│   ├── com/pharmacy
│   │   ├── controller     # API 控制器
│   │   ├── multitenant    # 多租户核心逻辑
│   │   ├── service        # 业务逻辑层
│   │   └── ...
├── src/main/resources     # 资源文件
│   ├── static             # 前端静态资源 (HTML/CSS/JS)
│   ├── application.yaml   # 应用配置
│   └── db/migration       # 数据库初始化脚本
├── docker                 # Docker 配置目录
├── docker-compose.yml     # 容器编排文件
└── pom.xml                # Maven 依赖配置
```

## ⚠️ 注意事项

1. **首次启动**: 系统会自动初始化多租户数据库结构和基础数据（如 `bht`, `wx` 等租户库）。
2. **端口占用**: 默认使用 `8080` (App) 和 `3306` (MySQL) 端口，请确保未被占用。
3. **Excel 导入**: 请使用系统提供的模板格式进行会员或药品的导入，否则可能解析失败。

